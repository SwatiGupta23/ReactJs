import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { decrement, incbyamt, increment } from "../redux/counter/Action";
const Counter = () => {
  const dispatch = useDispatch();

  const state = useSelector((state) => state.counterr);
  console.log(state);
  return (
    <div>
      <button onClick={() => dispatch(increment())}>Increment</button>
      <button onClick={() => dispatch(decrement())}>Decrement</button>
      <button onClick={() => dispatch(incbyamt(3))}>Increment by 3</button>
      <h1>{state.count}</h1>
    </div>
  );
};

export default Counter;
