import React from 'react'

const Testimonial = () => {
  return (
    <div>Testimonial</div>
  )
}

export default Testimonial