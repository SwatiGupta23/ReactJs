import logo from './logo.svg';
import './App.css';
import UseCallbackComp from './components/UseCallbackComp';
import UseMemoComp from './components/UseMemoComp';
import Main from './components/hoc/Main';

function App() {
  return (
    <div className="App">
      {/* <UseCallbackComp/> */}
      {/* <UseMemoComp/> */}
      <Main/>
    </div>
  );
}

export default App;
