import React from 'react'
import CompA from './CompA'

const Main = () => {
    const user = {name:"Shilwant",email:"shilwant@gmail.com",location:"Mumbai"}
  return (
    <div className='box'>
        <h2>Comp: Main</h2>
        <p>Name: {user.name} & Email: {user.email}</p>
        <CompA location={user.location}/>
    </div>
  )
}

export default Main