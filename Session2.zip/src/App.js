import React from 'react'
import './App.css'
import InlineStyleComp from './components/InlineStyleComp'
import InternalStyleComp from './components/InternalStyleComp'
import ExternalStyleComp from './components/ExternalStyleComp'
import BootstrapComp from './components/BootstrapComp'

const App = () => {
  return (
    <div>
      <h1>Hello world</h1>
      <InlineStyleComp/>
      <hr/>
      <InternalStyleComp/>
      <hr/>
      <ExternalStyleComp/>
      <hr/>
      <BootstrapComp/>
    </div>
  )
}

export default App
