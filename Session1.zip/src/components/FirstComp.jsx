import React from "react"
function FirstComp() {
    const name ='Shilwant'
    return (
        <>
        <h3>My name is {name}</h3>
            <h1>First Comp</h1>
            <p>Hello world</p>
        </>
    )
}

export default FirstComp