import { createAsyncThunk, isRejectedWithValue } from "@reduxjs/toolkit";
import axios from "axios";



export const addUser = createAsyncThunk("addUser", async (userdata, { rejectWithValue }) => {
    try {
        const { data } = await axios.post(
            `https://64c22b3efa35860baea148fe.mockapi.io/records/users`,
            userdata
        );

        return data;
    } catch (error) {
        return rejectWithValue(error);
    }
})

export const getUsers = createAsyncThunk(
    "getUsers",
    async(arg,{rejectWithValue})=>{
        try {
            const { data } = await axios.get(
              `https://64c22b3efa35860baea148fe.mockapi.io/records/users`
            );
            return data;
          } catch (error) {
            return rejectWithValue(error);
          }
    }
)