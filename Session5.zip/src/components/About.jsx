import React from 'react'
import BreadCrumb from './BreadCrumb'
import CardComp from './common/CardComp'
import { Row } from 'react-bootstrap'
import { data } from './data'
const About = () => {

  
  return (
    <div>
      <BreadCrumb pageName="About" />
      About
      
    <Row>
    {
        data.map((elem)=>{
          // return <CardComp key={elem.id} title={elem.title} description={elem.description} />

          return <CardComp key={elem.id} data={elem} type="about"/>
        })
      }
    </Row>
      </div>
  )
}

export default About