import React,{ Suspense, useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'
import Appbar from './components/Appbar'

const Home = React.lazy(() => import("./components/Home"))
const About = React.lazy(() => import("./components/About"))
function App() {

  return (
    <>
      <Router>
        <Appbar />
        <Suspense fallback={<h1>Loading...</h1>}>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/about-us' element={<About />} />
          </Routes>
        </Suspense>
      </Router>
    </>
  )
}

export default App
