import React from 'react'
import CompC from './CompC'

const CompB = ({location}) => {
    console.log("comp B: ",location)

  return (
    <div className='box'>
    <h2>Comp: Comp B</h2>
    <CompC location={location}/>
    </div>
  )
}

export default CompB
