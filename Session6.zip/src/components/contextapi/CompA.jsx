import React from 'react'
import CompB from './CompB'

const CompA = () => {
  return (
    <div className='box'>

      <h2>Comp: CompA</h2>
      <CompB/>
      </div>
  )
}

export default CompA