import React, { useEffect, useState } from 'react'

const UseEffectComp = () => {
    const [count,setCount] = useState(0)
    const [name,setName] = useState("Raj")
    useEffect(()=>{
        console.log('effect 1')
    })

    useEffect(()=>{
        console.log("effect 2")
    },[])

    useEffect(()=>{
        console.log("effect 3")
    },[count])

  return (
    <div>UseEffectComp
<h1>{count} - {name}</h1>
<button onClick={()=>setCount(count+1)}>Click me</button>
<button onClick={()=>setName("Vijay")}>Change Name</button>
    </div>
  )
}

export default UseEffectComp