import React from 'react';
import { Formik } from 'formik';
import { Card, Col, Row } from 'react-bootstrap';
import { resolve } from 'path';

const FormikForm = () => {
    return (
        <Row>
            <Col md={4}>
                <Card className='p-4 m-4'>
                    <div>
                        <Formik
                            initialValues={{ name:'',email: '', password: '',contact:"" }}
                            validate={values => {
                                const errors = {};
                                if(!values.name){
                                    errors.name = "Name is required."
                                }
                                if (!values.email) {
                                    errors.email = 'Email is required.';
                                } else if (
                                    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                                ) {
                                    errors.email = 'Invalid email address';
                                }
                                if(!values.password){
                                    errors.password= "Password is required."
                                }
                                if(!values.contact){
                                    errors.contact = "Contact is required."
                                }
                                return errors;
                            }}
                            onSubmit={(values, { setSubmitting,resetForm }) => {
                                setTimeout(() => {
                                    alert(JSON.stringify(values, null, 2));
                                    resetForm();
                                    setSubmitting(true);
                                }, 400);
                            }}
                        >
                            {({
                                values,
                                errors,
                                touched,
                                handleChange,
                                handleBlur,
                                handleSubmit,
                                isSubmitting,
                                resetForm
                                /* and other goodies */
                            }) => (
                                <form onSubmit={handleSubmit}>
                                    <input
                                        type="name"
                                        name="name"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        className='form-control mt-2'
                                        placeholder='Name'
                                        value={values.name}
                                    />
                                    {errors.name && touched.name && errors.name}
                                    <input
                                        type="email"
                                        name="email"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        className='form-control mt-2'
                                        placeholder='Email'
                                        value={values.email}
                                    />
                                    {errors.email && touched.email && errors.email}
                                    <input
                                        type="password"
                                        name="password"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        className='form-control mt-2'
                                        placeholder='******'
                                        value={values.password}
                                    />
                                    {errors.password && touched.password && errors.password}
                                    <input
                                        type="text"
                                        name="contact"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        className='form-control mt-2'
                                        placeholder='Contact'
                                        value={values.contact}
                                    />
                                    {errors.contact && touched.contact && errors.contact}
                                    <button type="submit" className='btn btn-primary mt-2' disabled={isSubmitting}>
                                        Submit
                                    </button>
                                </form>
                            )}
                        </Formik>
                    </div>
                </Card>
            </Col>
        </Row>
    )
}

export default FormikForm;

