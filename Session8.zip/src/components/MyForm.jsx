import React, { useState } from 'react'
import { Card, Col, Row } from 'react-bootstrap'

const MyForm = () => {
    let initial = {
        name:"",
        email:"",
        password:"",
        contact:""
    }
    const [user,setUser] = useState(initial)

    const onChangeHandler = (e)=>{
        const keyname = e.target.name
        const value = e.target.value;
        console.log(keyname,value)

        setUser({...user,[keyname]:value})
    }

    const onClickHandler = ( )=>{
        alert(JSON.stringify(user,null,2))
        setUser(initial)
    }
  return (
    <div>
        <Row>
            <Col md={4}>
                <Card className='p-4 m-4'>
                    <input type="text" name="name" onChange={onChangeHandler} value={user.name} placeholder='Name' className='form-control' /><br/>
                    <input type="text" name="email" onChange={onChangeHandler} value={user.email} placeholder='Email' className='form-control' /><br/>
                    <input type="text" name="password" onChange={onChangeHandler} value={user.password} placeholder='*******' className='form-control' /><br/>
                    <input type="text" name="contact" onChange={onChangeHandler} value={user.contact} placeholder='Contact' className='form-control' /><br/>
                    <button className='btn btn-primary' onClick={onClickHandler}>Submit</button>
                </Card>
            </Col>
        </Row>
    </div>
  )
}

export default MyForm