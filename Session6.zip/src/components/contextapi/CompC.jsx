import React,{useContext} from 'react'
import CompD from './CompD'
import { MovieContext,DataContext } from './Main'
const CompC = () => {
  const {user,subject} = useContext(DataContext);
  const movie = useContext(MovieContext)
  return (
    <div className='box'>

            <h2>Comp: CompC</h2>
            <p>Name: {user.name} & Location: {user.location} & Subject: {subject}</p>
            <p>Movie: {movie}</p>
            <hr/>
      <CompD/>
    </div>
  )
}

export default CompC