import logo from './logo.svg';
import './App.css';
import UseEffectComp from './components/UseEffectComp';
import APIinEffect from './components/APIinEffect';
import MyForm from './components/MyForm';
import FormikForm from './components/FormikForm';


function App() {
  return (
    <div className="App">
      {/* <MyForm/> */}
      <hr/>
    <FormikForm/>
      {/* <UseEffectComp/>
      <APIinEffect/> */}
      
    </div>
  );
}

export default App;
