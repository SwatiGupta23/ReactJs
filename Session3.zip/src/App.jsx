import logo from './logo.svg';
import './App.css';

import UseState from './components/UseState';
import InputValue from './components/InputValue';
function App() {
  console.log('app')
  return (
    <div className="App">
  <UseState/>
  <hr/>
  <InputValue/>
    </div>
  );
}

export default App;
