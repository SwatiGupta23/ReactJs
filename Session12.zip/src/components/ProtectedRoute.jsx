import React from 'react'
import Sidebar from './Sidebar'
import { Navigate, Outlet } from 'react-router-dom'

const ProtectedRoute = () => {
    const token = localStorage.getItem("token")
    return (
        <div>
            {
                token ?
                    <Sidebar>
                        <Outlet />
                    </Sidebar>
                    : <Navigate to="/" />
            }

        </div>
    )
}

export default ProtectedRoute
