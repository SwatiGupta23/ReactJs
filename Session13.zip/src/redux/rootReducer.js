import { combineReducers } from 'redux'
import { counterReducer } from './counter/Reducer'

const rootReducer = combineReducers({
    counterr: counterReducer,
})

export default rootReducer