import React from 'react'
import { MovieContext } from './Main'

const Sibling = () => {
    const movie = React.useContext(MovieContext)
  return (
    <div>Sibling - {movie}</div>
  )
}

export default Sibling