import React, { useEffect, useState } from 'react'

const APIinEffect = () => {
    const [users, setUsers] = useState([])
    function getUserData() {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(response => response.json())
            .then(json => {
                setUsers(json)
            })
    }

    useEffect(()=>{
        getUserData();
    },[])
    return (
        <div>APIinEffect
            <h1>User list</h1>
            {
                users && users.map(user => {
                    return (<p key={user.id}>{user.name}</p>)
                })
            }
        </div>
    )
}

export default APIinEffect