import React from 'react'
import CompC from './CompC'

const CompB = () => {
  return (
    <div className='box'>

        <h2>Comp: CompB</h2>
      <CompC/>
    </div>
  )
}

export default CompB