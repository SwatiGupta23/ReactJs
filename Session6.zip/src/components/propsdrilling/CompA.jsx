import React from 'react'
import CompB from './CompB'

const CompA = ({location}) => {
    console.log("comp A: ",location)
  return (
    <div className='box'>
    <h2>Comp: Comp A</h2>
    <CompB location={location}/>
</div>
  )
}

export default CompA