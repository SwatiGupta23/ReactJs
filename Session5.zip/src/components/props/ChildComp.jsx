import React from 'react'

const ChildComp = (props) => {
    console.log(props)
    const {heading,para,name} = props
  return (  
    <div style={{border:'1px solid red',width:400,m:3}}>
       <h1>{heading}</h1>
       <h5>{name.firstName} {name.lastName}</h5>
       <p>{para} Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto libero ipsum corrupti facere adipisci in totam ad, nobis ex, accusamus quasi et at obcaecati eos harum inventore quam recusandae nulla.</p> 
    </div>
  )
}

export default ChildComp