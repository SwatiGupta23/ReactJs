import React from 'react'

const About = () => {
  return (
    <div>
      About us
    </div>
  )
}

export default About
