const initialState = {
    users: [],
    user: {},
    isLoading: false,
    error: null,
    success: null
}

const userReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_USER_PENDING':
            return {
                ...state,
                isLoading: true
            }

        case 'ADD_USER_SUCCESS':
            return {
                ...state,
                isLoading: false,
                user: action.payload 
            }
        case 'ADD_USER_FAILED':
            return {
                ...state,
                isLoading: false,
                error: action.payload
            }
        case 'GET_USERS_PENDING':
            return {
                ...state,
                isLoading: true
            }

        case 'GET_USERS_SUCCESS':
            return {
                ...state,
                isLoading: false,
                users: action.payload 
            }
        case 'GET_USERS_FAILED':
            return {
                ...state,
                isLoading: false,
                error: action.payload
            }

        default:
            return state;
    }
}

export default userReducer