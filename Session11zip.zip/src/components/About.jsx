import React, { useEffect } from "react";
import api from "../interceptor";
const About = () => {
  useEffect(() => {
    api
      .get("/products")
      .then((res) => {
        console.log(res);
      })
      .catch((err) => console.log(err));
  }, []);
  return <div>about</div>;
};

export default About;
