import React, { createContext } from 'react'
import CompA from './CompA'
import Sibling from './Sibling';

export const DataContext = createContext();
export const MovieContext = createContext();
const Main = () => {
    const user = {name:"Shilwant",email:"shilwant@gmail.com",location:"Mumbai"}
    const movie = "12 Fail";
    const subject = "Math"

  return (
    <div className='box'>
        <h2>Comp: Main</h2>
        <p>Name: {user.name} & Email: {user.email}</p>
        <MovieContext.Provider value={movie}>
          <DataContext.Provider value={{user,subject}}>
            <CompA/>
            
          </DataContext.Provider>
          <Sibling/>
        </MovieContext.Provider>
    </div>
  )
}

export default Main