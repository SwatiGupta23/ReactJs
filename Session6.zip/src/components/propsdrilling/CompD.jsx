import React from 'react'

const CompD = ({location}) => {
    console.log("comp D: ",location)

  return (
    <div>CompD

        <p>Location: {location}</p>
    </div>
  )
}

export default CompD