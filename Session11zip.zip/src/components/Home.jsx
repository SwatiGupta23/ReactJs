import React, { useEffect } from "react";
import axios from "axios";
const Home = () => {
  useEffect(() => {
    axios
      .get("https://dummyjson.com/posts", {
        headers: {
          Authorization:
            "tokens ljkadslpf jaslpfjaslpfjasopjfoaspjf asojf sodos",
        },
      })
      .then((res) => {
        console.log(res);
      })
      .catch((err) => console.log(err));
  }, []);
  return <div>home</div>;
};

export default Home;
