import React from 'react'
import BreadCrumb from './BreadCrumb'

const Contact = () => {
  return (
    <div>
      <BreadCrumb pageName="Contact Us" />
      Contact</div>
  )
}

export default Contact