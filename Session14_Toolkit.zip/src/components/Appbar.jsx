import React from "react";
import { Link } from "react-router-dom";
const Appbar = () => {
  return (
    <div className="d-flex me-auto p-4 bg-secondary mb-2">
      <Link className="text-light mx-2" to="/">User List</Link> |
      <Link className="text-light mx-2" to="/add-user">Add User</Link>
    </div>
  );
};

export default Appbar;
