import React, { useState } from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  const [todo, setTodo] = useState(['list item1'])
  return (
    <div>Home

      Go to <Link to="/contact">Contact</Link>

      <h1>Todo list</h1>
      {
        todo.map((elem, index) => {
          return (<div key={index}>

            <p>{elem} <button>Delete</button></p>
          </div>)
        })
      }
    </div>
  )
}

export default Home