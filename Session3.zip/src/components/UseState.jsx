import React,{useState} from 'react'

const UseState = () => {
    // const [state_name,state_method] = useState(initial_value)
console.log('child comp')
    const [count,setCount] = useState(0);
    const [myName,setMyName] = useState("Kumar")
    const name = "Shilwant"

    const onClickHandler=()=>{
      setCount(count + 1)

    }

    const changeName = () =>{
        setMyName("Gupta")
    }

    const incrementByAmount = (num) =>{
        setCount(count + num)
    }
  return (
    <div>
        <h1>Name: {myName}</h1>
        <h1>count: {count}</h1>
        <button onClick={onClickHandler}>Click me</button>
        <button onClick={()=>incrementByAmount(3)}>Increment by 3</button>
        <button onClick={changeName}>Change Name</button>
    </div>
  )
}

export default UseState