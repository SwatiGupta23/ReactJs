import React from 'react'
import image1 from './../images/logo.svg'
const InternalStyleComp = () => {
    const heading={
        color:"#fff",
        backgroundColor:"black",
        padding:"4rem"
    }
  return (
    <div>
        <h1 style={heading}>Internal Style Component</h1>
        <img src="https://img.freepik.com/free-psd/realistic-business-card-mockup_1051-1544.jpg" alt='anything' height={100} width={100} />

        <img src={image1} alt='logo' height={100} width={100} />
    </div>
  )
}

export default InternalStyleComp
