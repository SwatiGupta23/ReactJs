import React, { useState } from "react";
import { Card, Col, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { addUser } from "../redux/users/Action";
const AddUser = () => {
  const [user, setUser] = useState({});
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const onChangeHandler = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const onSubmitHandler = () => {
    dispatch(addUser(user))
    navigate('/')
  };
  return (
    <div>
      <Row className="justify-content-center">
        <Col md={4}>
          <Card className="p-4 m-4">
            <h1>Add User</h1>
            <input
              type="text"
              name="name"
              onChange={onChangeHandler}
              placeholder="Name"
              className="form-control mt-2"
            />
            <input
              type="text"
              name="email"
              onChange={onChangeHandler}
              placeholder="Email"
              className="form-control mt-2"
            />
            <input
              type="password"
              name="password"
              onChange={onChangeHandler}
              placeholder="********"
              className="form-control mt-2"
            />
            <input
              type="text"
              name="contact"
              onChange={onChangeHandler}
              placeholder="Contact"
              className="form-control mt-2"
            />

            <button className="btn btn-primary mt-5" onClick={onSubmitHandler}>
              Submit
            </button>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AddUser;
