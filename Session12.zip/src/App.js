import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SignIn from './components/auth/SignIn';
import Dashboard from './components/Dashboard';
import Users from './components/Users';
import ProtectedRoute from './components/ProtectedRoute';
import PublicRoutes from './components/PublicRoutes';
function App() {
  return (
    <div className="App">
      <Router>
        <Routes>

          <Route path="/" element={<PublicRoutes />}>
            <Route path='/' element={<SignIn />} />
          </Route>


          <Route path='/' element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path='/users' element={<Users />} />
          </Route>


        </Routes>
      </Router>
    </div>
  );
}

export default App;
