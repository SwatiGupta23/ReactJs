import React from 'react'
import { DataContext, MovieContext } from './Main'
const CompD = () => {
  return (
    <div>CompD
      <MovieContext.Consumer>
        {
          (data) => {
            return <div>
              Movie: {data}

              <DataContext.Consumer>
                {
                  (data) => {
                    return <p>Name: {data.user.name} & Location: {data.user.location}</p>
                  }
                }
              </DataContext.Consumer>
            </div>
          }
        }
      </MovieContext.Consumer>
    </div>
  )
}

export default CompD