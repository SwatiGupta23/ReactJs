import React from 'react'
import ChildComp from './ChildComp'
import BreadCrumb from '../BreadCrumb'

const ParentComp = () => {
  return (
    <>
    <BreadCrumb pageName="Props" />
    <div style={{display:'flex'}}>

<ChildComp heading="Heading1" para="Para1" name={{firstName:"Shilwant",lastName:"Gupta"}}/>
<ChildComp heading="Heading2" para="Para2" name={{firstName:"Amit",lastName:"Verma"}}/>

</div>
    </>
  )
}

export default ParentComp