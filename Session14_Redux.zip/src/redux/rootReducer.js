import { combineReducers } from "redux";
import userReducer from "./users/Reducer";

const rootReducer = combineReducers({
    userr:userReducer
})

export default rootReducer