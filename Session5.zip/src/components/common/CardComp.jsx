import { Col } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

function CardComp({ data, type }) {
    return (
        <Col md={4}>
            <Card>
                <Card.Img variant="top" src="holder.js/100px180" />
                <Card.Body>
                    <Card.Title>{data.title}</Card.Title>
                    <Card.Text>
                        {data.description}
                    </Card.Text>
                    {
                        type == 'home' ?
                            <Button variant="primary">Go somewhere</Button>
                            :
                            <Button variant="primary">Read More</Button>

                    }
                </Card.Body>
            </Card>
        </Col>
    );
}

export default CardComp;