const InlineStyleComp = () =>{
    return (
        <>
            <h1 style={{color:"#fff",backgroundColor:"blue",padding:"4rem"}}>Inline Style Component</h1>
        </>
    )
}

export default InlineStyleComp;