import React from 'react'
import CompD from './CompD'

const CompC = ({location}) => {
    console.log("comp C: ",location)

  return (
    <div className='box'>
    <h2>Comp: Comp C</h2>
    <CompD location={location}/>
    </div>
  )
}

export default CompC