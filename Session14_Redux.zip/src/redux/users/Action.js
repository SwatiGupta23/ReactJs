import axios from "axios";

export const addUser = (userdata) => {
    return (dispatch) => {
        dispatch({ type: "ADD_USER_PENDING" });
        axios.post('https://666d1f0f7a3738f7cacb86f3.mockapi.io/records/users', userdata)
            .then((res) => {
                const data = res.data;
                dispatch({ type: "ADD_USER_SUCCESS", payload: data })
            })
            .catch(err => {
                dispatch({ type: "ADD_USER_FAILED", payload: err.message })
            })
    }
}

export const getUsers = () => {
    return (dispatch) => {
        dispatch({ type: "GET_USERS_PENDING" });
        axios.get("https://666d1f0f7a3738f7cacb86f3.mockapi.io/records/users")
            .then((res) => {
                const data = res.data;
                dispatch({ type: "GET_USERS_SUCCESS", payload: data })
            })
            .catch(err => {
                dispatch({ type: "GET_USERS_FAILED", payload: err.message })
            })
    }
}