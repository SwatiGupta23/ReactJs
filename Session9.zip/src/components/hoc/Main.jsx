import React from 'react'
import HoverIncrease from './HoverIncrease'
import ClickIncrease from './ClickIncrease'

const Main = () => {
  return (
    <div>
        <HoverIncrease />
        <ClickIncrease lastname="test"/>
    </div>
  )
}

export default Main