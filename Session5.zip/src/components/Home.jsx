import React, { useState } from 'react'
import { Row } from 'react-bootstrap'
import CardComp from './common/CardComp'
import { data } from './data'

const Home = () => {
  return (
    <div>Home
  
  <Row> 
    {
        data.map((elem)=>{
          // return <CardComp key={elem.id} title={elem.title} description={elem.description} />

          return <CardComp key={elem.id} data={elem} type="home" />
        })
      }
    </Row>
    </div>
  )
}

export default Home