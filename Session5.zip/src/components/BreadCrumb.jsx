import React from 'react'

const BreadCrumb = ({pageName}) => {
  return (
    <div style={{backgroundColor:"blue",color:'white',padding:40}}>Home / {pageName}</div>
  )
}

export default BreadCrumb