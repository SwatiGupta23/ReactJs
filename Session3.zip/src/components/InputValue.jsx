import React from 'react'

const InputValue = () => {
    const [input,setInput] = React.useState("")

    const onChangeHandler = (event) =>{
        console.log('test',event.target.value)
        setInput(event.target.value)
    }
  return (
    <div>
        <input type="text"  placeholder='Enter something...' onChange={onChangeHandler} />
        <h1>{input}</h1>
    </div>
  )
}

export default InputValue