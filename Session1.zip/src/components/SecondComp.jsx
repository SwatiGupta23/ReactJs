import React from 'react'

const SecondComp = () => {
  return (
    <div>SecondComp</div>
  )
}

export const Third = () =>{
    return (
        <h1>Third Comp</h1>
    )
}

export default SecondComp