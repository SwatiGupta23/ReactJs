import React from "react";
const HOC = (OriginalComponent) => (props) => {
  return <OriginalComponent name="LogRocket" style={{backgroundColor:"red",color:"white"}} {...props} />;
};

export default HOC;

