import React from "react";
import { Formik } from "formik";
import { Row, Col, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import axios from "axios";
const AddUser = () => {
  const navigate = useNavigate();
  return (
    <div>
      <Row>
        <Col md={4}>
          <Card className="m-4 p-4">
            <h3>Add User</h3>
            <Formik
              initialValues={{ name: "", email: "", password: "", contact: "" }}
              validate={(values) => {
                const errors = {};
                if (!values.name) {
                  errors.name = "Name is required.";
                }
                if (!values.email) {
                  errors.email = "Email is required";
                } else if (
                  !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                ) {
                  errors.email = "Invalid email address";
                }
                if (!values.password) {
                  errors.password = "password is required.";
                }
                if (!values.contact) {
                  errors.contact = "contact is required.";
                }
                return errors;
              }}
              onSubmit={(values, { setSubmitting }) => {
                setTimeout(() => {
                  axios
                    .post(
                      "https://666d1f0f7a3738f7cacb86f3.mockapi.io/records/users",
                      values
                    )
                    .then((res) => {
                      console.log(res);
                      navigate("/");
                    })
                    .catch((err) => console.log(err));
                  // alert(JSON.stringify(values, null, 2));
                  setSubmitting(false);
                }, 400);
              }}
            >
              {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                isSubmitting,
                /* and other goodies */
              }) => (
                <form onSubmit={handleSubmit}>
                  <input
                    type="text"
                    name="name"
                    placeholder="name"
                    className="form-control m-2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                  />
                  {errors.name && touched.name && errors.name}
                  <input
                    type="email"
                    name="email"
                    placeholder="email"
                    className="form-control m-2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.email}
                  />
                  {errors.email && touched.email && errors.email}
                  <input
                    type="password"
                    name="password"
                    placeholder="password"
                    className="form-control m-2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.password}
                  />
                  {errors.password && touched.password && errors.password}
                  <input
                    type="text"
                    name="contact"
                    placeholder="contact"
                    className="form-control m-2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.contact}
                  />
                  {errors.contact && touched.contact && errors.contact}
                  <button
                    type="submit"
                    className="mt-4 btn btn-primary"
                    disabled={isSubmitting}
                  >
                    Submit
                  </button>
                </form>
              )}
            </Formik>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AddUser;
