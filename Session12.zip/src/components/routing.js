import { AiFillDashboard } from "react-icons/ai";
import { FaUserFriends } from "react-icons/fa";

export const routing = [
    {
        url:'/dashboard',
        label:"Dashboard",
        icon:<AiFillDashboard size={20} />
    },
    {
        url:'/users',
        label:"Users",
        icon:<FaUserFriends size={20} />
    }
]