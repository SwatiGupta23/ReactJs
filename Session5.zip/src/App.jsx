import logo from './logo.svg';
import './App.css';
import Appbar from './components/Appbar';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NotFound from './components/NotFound';
import ParentComp from './components/props/ParentComp';
function App() {
  console.log('app')
  return (
    <div className="App">
   

      <Router>
      <Appbar />
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/about' element={<About/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path='/props' element={<ParentComp/>} />
          <Route path='*' element={<NotFound/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
