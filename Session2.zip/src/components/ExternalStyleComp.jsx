import React from 'react'
import './external.css'
const ExternalStyleComp = () => {
  return (
    <>
      <h1 className="heading">External Style Component</h1>
    </>
  )
}

export default ExternalStyleComp
