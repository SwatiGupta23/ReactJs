import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Appbar from './components/Appbar';
import ListUser from './components/ListUser';
import AddUser from './components/AddUser';
import EditUser from './components/EditUser';
function App() {
  return (
    <div className="App">
    <Router>
      <Appbar/>
      <Routes>
        <Route path='/' element={<ListUser/>} />
        <Route path="/add-user" element={<AddUser/>} />
        <Route path='/edit-user/:userid' element={<EditUser/>} />
      </Routes>
    </Router>
    </div>
  );
}

export default App;
