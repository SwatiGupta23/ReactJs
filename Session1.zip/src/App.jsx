import logo from './logo.svg';
import './App.css';
import FirstComp from './components/FirstComp';
import MyComp,{Third as ThirdComp} from './components/SecondComp';
function App() {
  return (
    <div className="App">
      <h1>Hello</h1>
      <FirstComp/>
      <MyComp/>
      <ThirdComp/>
    </div>
  );
}

export default App;
