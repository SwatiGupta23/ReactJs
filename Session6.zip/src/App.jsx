import logo from './logo.svg';
import './App.css';
import Main from './components/propsdrilling/Main';
import ContextMain from './components/contextapi/Main'

function App() {
  return (
    <div className="App">
      {/* <Main/> */}
      <ContextMain/>
    </div>
  );
}

export default App;
