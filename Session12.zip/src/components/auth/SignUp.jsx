import React from 'react'

const SignUp = () => {
  return (
    <div>
      sign up
    </div>
  )
}

export default SignUp
