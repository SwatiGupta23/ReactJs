import logo from './logo.svg';
import './App.css';
import UseReducerComp from './components/UseReducerComp';


function App() {
  return (
    <div className="App">
  <UseReducerComp/>
    </div>
  );
}

export default App;
