import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
const ListUser = () => {
  const [users, setUsers] = React.useState([]);
  const [isLoading, setIsLoading] = useState(false);
  function getUserData() {
    setIsLoading(true);
    axios
      .get("https://666d1f0f7a3738f7cacb86f3.mockapi.io/records/users")
      .then((res) => {
        console.log(res.data);
        setUsers(res.data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.log(err);
        setIsLoading(false);
      });
  }

  useEffect(() => {
    getUserData();
  }, []);

  const onDeleteHandler = (userid) => {
    if (window.confirm("Are you sure, you want to delete?") == true) {
      axios
        .delete(
          "https://666d1f0f7a3738f7cacb86f3.mockapi.io/records/users/" + userid
        )
        .then((res) => {
          getUserData();
        })
        .catch((err) => console.log(err));
    } else {
      console.log("cancel");
    }
  };
  return (
    <div>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Sr. No.</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <h1>Loading...</h1>
          ) : (
            users &&
            users.map((user, index) => {
              return (
                <tr key={user.id}>
                  <td>{++index}</td>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.contact}</td>
                  <td>
                    <button>
                      <Link to={"/edit-user/" + user.id}>Edit</Link>
                    </button>
                    <button onClick={() => onDeleteHandler(user.id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ListUser;
