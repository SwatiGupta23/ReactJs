import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom'
import Home from './components/Home';
import About from './components/About';
function App() {
  return (
    <div className="App">
      <Router>
        <NavLink to="/">Home </NavLink> | <NavLink to="/about">About</NavLink> <br />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </Router>

    </div>
  );
}

export default App;
